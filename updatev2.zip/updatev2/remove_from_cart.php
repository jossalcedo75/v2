<?php
session_start();

// Check if the product_id to remove is set
if (isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];

    // Remove item from the cart
    if (isset($_SESSION['cart'][$product_id])) {
        unset($_SESSION['cart'][$product_id]);
    }

    // Redirect back to the cart page
    header('Location: cart.php');
    exit(); // Always call exit after header redirects
} else {
    // Consider adding some error handling to display a message or log an error
    header('Location: cart.php');
    exit();
}
?>
