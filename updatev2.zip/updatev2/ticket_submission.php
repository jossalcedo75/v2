<?php
// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the data from the form
    $username = $_POST['username'] ?? 'Anonymous';
    $subject = $_POST['subject'] ?? 'No Subject';
    $description = $_POST['description'] ?? 'No Description';

    // Sanitize the input
    $username = filter_var($username, FILTER_SANITIZE_STRING);
    $subject = filter_var($subject, FILTER_SANITIZE_STRING);
    $description = filter_var($description, FILTER_SANITIZE_STRING);
    $email = $_POST['email'] ?? '';

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        // Sanitize email
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    }
    // Prepare the ticket string
    $ticket = "Username: {$username}\nSubject: {$subject}\nDescription: {$description}\n";
    $ticket .= "----------------------------------------\n";

    // File to save the tickets
    $file = 'tickets.txt';

    // Write the ticket to the text file
    file_put_contents($file, $ticket, FILE_APPEND | LOCK_EX);

    // Provide a success message
    $success = "Your ticket has been submitted successfully.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Submit a Ticket</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; }
        .container { max-width: 600px; margin: auto; }
        form { margin-top: 20px; }
        label { display: block; margin-bottom: 5px; }
        textarea, input[type="text"] { width: 100%; margin-bottom: 15px; padding: 10px; }
        input[type="submit"] { padding: 10px 15px; background: #007bff; color: white; border: none; cursor: pointer; }
        input[type="submit"]:hover { background: #0056b3; }
        .success { background-color: #ddffdd; padding: 10px; margin-top: 15px; border: 1px solid #green; }
    </style>
</head>
<body>
<nav> 
            <ul> 
                <li><a href="shop.php">Home</a></li> 
                
            </ul> 
        </nav> 
    <div class="container">
        <h1>Submit a Ticket</h1>
        <?php if (!empty($success)): ?>
        <div class="success">
            <?php echo $success; ?>
        </div>
        <?php endif; ?>
        <form action="ticket_submission.php" method="post">
            <label for="username">Your Name:</label>
            <input type="text" id="username" name="username" required>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            <label for="subject">Subject:</label>
            <input type="text" id="subject" name="subject" required>

            <label for="description">Description:</label>
            <textarea id="description" name="description" rows="6" required></textarea>

            <input type="submit" value="Submit Ticket">
        </form>
    </div>
</body>
</html>
