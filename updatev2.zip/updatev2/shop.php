<?php 
session_start(); 

// Check if the 'add_to_cart' button is clicked 
if (isset($_POST["add_to_cart"])) { 
    // Get the product ID and quantity from the form 
    $product_id = $_POST["product_id"]; 
    $product_quantity = $_POST["product_quantity"]; 

    // Initialize or update the cart session variable
    if (!isset($_SESSION["cart"])) { 
        $_SESSION["cart"] = []; 
    }
    $_SESSION["cart"][$product_id] = $product_quantity; 
    header("location:cart.php"); 
} 
?> 
<!DOCTYPE html> 
<html> 
    <head> 
        <title>USB Gurus Shopping</title> 
        <link rel="stylesheet" href="shop.css"> 
    </head> 
    <body> 
        <header> 
            <h1>Welcome to USB Gurus Shopping Portal</h1> 
        </header> 
        <nav> 
            <ul> 
                <li><a href="shop.php">Home</a></li> 
                <li> 
				<a href= 
"mailto:helpdesk@usbguru.com">Contact Us</a> 
			</li> 
                <li><a href="ticket_submission.php">Submit A Ticket</a></li> 
                <li><a href="cart.php">Cart</a></li> 
                <li><a href="logout.php">Logout</a></li> 
            </ul> 
        </nav> 
        <main> 
            <section> 
                <h2>Featured USBs</h2> 
                <ul> 
                    <li> 
                        <h3>USB 3.0 Flash Drive</h3> 
                        <img src="https://www.integralmemory.com/wp-content/uploads/2022/02/USB_INFDXGBTURBWH3-0_P1.jpg" alt="USB 3.0 Flash Drive"> 
                        <p>High-speed data transfer</p> 
                        <p><span>$15</span></p> 
                        <form method="post" action="shop.php"> 
                            <input type="hidden" name="product_id" value="1"> 
                            <label for="product1_quantity">Quantity:</label> 
                            <input type="number" id="product1_quantity" name="product_quantity" min="1" max="10"> 
                            <button type="submit" name="add_to_cart">Add to Cart</button> 
                        </form> 
                    </li> 
                    <li> 
                        <h3>Wireless USB Adapter</h3> 
                        <img src="https://pisces.bbystatic.com/image2/BestBuy_US/images/products/6492/6492168_sd.jpg;maxHeight=640;maxWidth=550" alt="Wireless USB Adapter"> 
                        <p>Connect to wireless networks effortlessly</p> 
                        <p><span>$20</span></p> 
                        <form method="post" action="shop.php"> 
                            <input type="hidden" name="product_id" value="2"> 
                            <label for="product2_quantity">Quantity:</label> 
                            <input type="number" id="product2_quantity" name="product_quantity" min="1" max="10"> 
                            <button type="submit" name="add_to_cart">Add to Cart</button> 
                        </form> 
                    </li> 
                    <li> 
                        <h3>USB C Hub</h3> 
                        <img src="https://pisces.bbystatic.com/image2/BestBuy_US/images/products/6493/6493177_sd.jpg;maxHeight=640;maxWidth=550" alt="USB C Hub"> 
                        <p>Multifunctional USB C hub</p> 
                        <p><span>$35</span></p> 
                        <form method="post" action="shop.php"> 
                            <input type="hidden" name="product_id" value="3"> 
                            <label for="product3_quantity">Quantity:</label> 
                            <input type="number" id="product3_quantity" name="product_quantity" min="1" max="10"> 
                            <button type="submit" name="add_to_cart">Add to Cart</button> 
                        </form> 
                    </li> 
                </ul> 
            </section> 
        </main> 
        <footer> 
            <p>&copy; 2024 USB Gurus Shopping Portal</p> 
        </footer> 
    </body> 
</html>
