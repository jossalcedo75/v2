<?php 

if ($_SERVER["REQUEST_METHOD"] == "POST") { 
	$username = $_POST["username"]; 
	$password = $_POST["password"]; 

	// Connect to the database 
	$host = "localhost"; 
	$dbname = "shp"; 
	$username_db = "root"; 
	$password_db = ""; 

	try { 
		$db = new PDO( 
			"mysql:host=$host;dbname=$dbname", 
			$username_db, 
			$password_db
		); 
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 

		// Check if the user exists in the database 
		$stmt = $db->prepare("SELECT * FROM users WHERE username = :username"); 
		$stmt->bindParam(":username", $username); 
		$stmt->execute(); 
		$user = $stmt->fetch(PDO::FETCH_ASSOC); 

		if ($user) { 
			// Verify the password 
			if (password_verify($password, $user["password"])) { 
				session_start(); 
				$_SESSION["user"] = $user; 

				echo '<script type="text/javascript"> 
	window.onload = function () { 
		alert("Welcome to USB GURU shopping website"); 
		window.location.href = "shop.php"; 
	}; 
</script> 
'; 
			} else { 
				echo "<h2>Login Failed</h2>"; 
				echo "Invalid email or password."; 
			} 
		} else { 
			echo "<h2>Login Failed</h2>"; 
			echo "User doesn't exist"; 
		} 
	} catch (PDOException $e) { 
		echo "Connection failed: " . $e->getMessage(); 
	} 
} 
?>
<!DOCTYPE html> 
<html>
<head> 
    <title>USB Gurus Shopping Portal</title> 
    <link rel="stylesheet" href="shop.css"> 
</head> 

<body> 
    <header>
        <h1>Welcome to USB Gurus Shopping Portal</h1>
    </header>
    <nav>
        <ul>
            <!-- Added classes for styling -->
            <li> 
				<a href= 
"mailto:helpdesk@usbguru.com">Contact Us</a> 
			</li> 
			<li> 
            <li><a href="register.php" class="nav-item">Register</a></li>
        </ul>
    </nav>
    <main>
        <!-- Aligned login to the right and set as a sidebar -->
        <aside class="login-form">
            <form method="post" action="login.php">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
                <input type="submit" value="Login">
                <p>Don't have an account? <a href="register.php">Register Here</a></p>
            </form>
        </aside>
        <!-- Product section styled as the main content -->
        <section class="product-display"> 
            <h2>Featured USBs</h2> 
            <!-- Added classes for flex layout -->
            <ul class="products-list"> 
                <li class="product-item"> 
                    <h3>USB 3.0 Flash Drive</h3> 
                    <img src="https://www.integralmemory.com/wp-content/uploads/2022/02/USB_INFDXGBTURBWH3-0_P1.jpg" alt="USB 3.0 Flash Drive"> 
                    <p>High-speed data transfer</p> 
                    <p><span>$15</span></p> 
                </li> 
                <li class="product-item"> 
                    <h3>Wireless USB Adapter</h3> 
                    <img src="https://pisces.bbystatic.com/image2/BestBuy_US/images/products/6492/6492168_sd.jpg" alt="Wireless USB Adapter"> 
                    <p>Connect to wireless networks effortlessly</p> 
                    <p><span>$20</span></p> 
                </li> 
                <li class="product-item"> 
                    <h3>USB C Hub</h3> 
                    <img src="https://pisces.bbystatic.com/image2/BestBuy_US/images/products/6493/6493177_sd.jpg" alt="USB C Hub"> 
                    <p>Multifunctional USB C hub</p> 
                    <p><span>$35</span></p> 
                </li> 
            </ul> 
        </section> 
    </main>
    <footer>
        <p>&copy; 2024 USB Gurus Shopping Portal</p>
    </footer>
</body> 
</html>
